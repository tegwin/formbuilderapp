<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Builder</title>
    <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
    <div class="dfb-admin-wrapper">
        <header class="dfb-admin-header">
            <h1>Dynamic Form Builder</h1>
        </header>
        <div class="dfb-admin-content">
</div>
        <footer class="dfb-admin-footer">
            <p>Form Builder v1.0</p>
        </footer>
    </div>
</body>
</html>